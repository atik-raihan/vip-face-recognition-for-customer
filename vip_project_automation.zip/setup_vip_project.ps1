# VIP Recognition Project - One-click PowerShell setup/check
# Run from ANYWHERE:
#   powershell -ExecutionPolicy Bypass -File .\setup_vip_project.ps1
#
# The script finds the Django project automatically under the current folder
# (or under D:\Downloads\vip-recognition-core), creates a backup before
# changing anything, checks the POS recognition endpoint, runs Django checks
# and migrations, and writes a status report.

$ErrorActionPreference = "Continue"

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host " VIP RECOGNITION PROJECT - AUTO SETUP/CHECK" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""

function Find-ProjectRoot {
    $candidates = @(
        (Get-Location).Path,
        "D:\Downloads\vip-recognition-core",
        "D:\Downloads\vip-recognition-core\vip-recognition",
        "D:\Downloads\vip-recognition-core\vip-recognition\dashboard"
    )

    foreach ($base in $candidates) {
        if (-not (Test-Path $base)) { continue }

        $manage = Get-ChildItem -Path $base -Filter "manage.py" -File -Recurse -ErrorAction SilentlyContinue |
                  Select-Object -First 1

        if ($manage) {
            return $manage.Directory.FullName
        }
    }

    return $null
}

$root = Find-ProjectRoot

if (-not $root) {
    Write-Host "ERROR: manage.py was not found." -ForegroundColor Red
    Write-Host "Put this script inside D:\Downloads\vip-recognition-core or the Django project folder and run it again."
    exit 1
}

Set-Location $root
Write-Host "Django project: $root" -ForegroundColor Green

# Find Python
$python = $null
$venvCandidates = @(
    (Join-Path $root "..\..\venv\Scripts\python.exe"),
    (Join-Path $root "..\venv\Scripts\python.exe"),
    (Join-Path $root "venv\Scripts\python.exe"),
    "D:\Downloads\vip-recognition-core\venv\Scripts\python.exe"
)

foreach ($p in $venvCandidates) {
    if (Test-Path $p) {
        $python = (Resolve-Path $p).Path
        break
    }
}

if (-not $python) {
    $cmdPython = Get-Command python -ErrorAction SilentlyContinue
    if ($cmdPython) { $python = $cmdPython.Source }
}

if (-not $python) {
    Write-Host "ERROR: Python was not found." -ForegroundColor Red
    exit 1
}

Write-Host "Python: $python" -ForegroundColor Green

# Backup relevant files before any automatic edit.
$backup = Join-Path $root ("_auto_backup_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
New-Item -ItemType Directory -Path $backup -Force | Out-Null

$important = @(
    "face_recognition_app\views.py",
    "face_recognition_app\camera\live_ai_camera.py",
    "customer\models.py",
    "customers\models.py",
    "templates\pos.html",
    "face_recognition_app\templates\face_recognition_app\camera.html",
    "face_recognition_app\templates\face_recognition_app\dashboard.html"
)

foreach ($rel in $important) {
    $src = Join-Path $root $rel
    if (Test-Path $src) {
        $dest = Join-Path $backup ($rel -replace "[\\/]","__")
        Copy-Item $src $dest -Force
    }
}

Write-Host "Backup created: $backup" -ForegroundColor Yellow

# Locate views.py
$views = Get-ChildItem -Path $root -Filter "views.py" -File -Recurse |
         Where-Object { $_.FullName -match "face_recognition_app" } |
         Select-Object -First 1

# Locate POS template
$pos = Get-ChildItem -Path $root -Filter "*.html" -File -Recurse |
       Where-Object { $_.Name -match "pos" } |
       Select-Object -First 1

# Locate urls.py
$urls = Get-ChildItem -Path $root -Filter "urls.py" -File -Recurse |
        Where-Object { $_.FullName -match "face_recognition_app" } |
        Select-Object -First 1

Write-Host ""
Write-Host "---- FILE DISCOVERY ----" -ForegroundColor Cyan
if ($views) { Write-Host "views.py : $($views.FullName)" -ForegroundColor Green }
else { Write-Host "views.py : NOT FOUND" -ForegroundColor Red }

if ($pos) { Write-Host "POS HTML : $($pos.FullName)" -ForegroundColor Green }
else { Write-Host "POS HTML : NOT FOUND" -ForegroundColor Yellow }

if ($urls) { Write-Host "App urls : $($urls.FullName)" -ForegroundColor Green }
else { Write-Host "App urls : NOT FOUND" -ForegroundColor Yellow }

# Static code checks
$report = @()
$report += "VIP Recognition Project Status"
$report += "Generated: $(Get-Date)"
$report += "Project root: $root"
$report += ""

function Add-Check($name, $ok, $detail) {
    if ($ok) {
        Write-Host "[PASS] $name - $detail" -ForegroundColor Green
        $script:report += "[PASS] $name - $detail"
    } else {
        Write-Host "[WARN] $name - $detail" -ForegroundColor Yellow
        $script:report += "[WARN] $name - $detail"
    }
}

if ($views) {
    $text = Get-Content $views.FullName -Raw
    Add-Check "latest_recognition exists" ($text -match "def\s+latest_recognition\s*\(") "Endpoint function found"
    Add-Check "JsonResponse used" ($text -match "JsonResponse") "Recognition endpoint can return JSON"
    Add-Check "RecognitionLog used" ($text -match "RecognitionLog") "Recognition log model is connected"
} else {
    Add-Check "views.py" $false "Could not find face_recognition_app/views.py"
}

if ($urls) {
    $u = Get-Content $urls.FullName -Raw
    Add-Check "latest-recognition route" ($u -match "latest-recognition") "Route text found"
} else {
    Add-Check "app urls.py" $false "Could not find face_recognition_app/urls.py"
}

if ($pos) {
    $ptext = Get-Content $pos.FullName -Raw
    Add-Check "POS customer selector" ($ptext -match 'id\s*=\s*["'']customer["'']') "Customer dropdown found"
    Add-Check "Welcome Back modal" ($ptext -match 'welcome-back-modal') "Popup HTML found"
    Add-Check "Recognition polling" ($ptext -match 'latest-recognition') "POS polls recognition endpoint"
    Add-Check "Snapshot display" ($ptext -match 'wb-photo') "Popup has recognition snapshot element"
} else {
    Add-Check "POS template" $false "Could not find POS HTML"
}

# Run Django checks and migrations.
Write-Host ""
Write-Host "---- DJANGO CHECK ----" -ForegroundColor Cyan
& $python manage.py check
$checkExit = $LASTEXITCODE
Add-Check "python manage.py check" ($checkExit -eq 0) "Exit code $checkExit"

Write-Host ""
Write-Host "---- MIGRATIONS ----" -ForegroundColor Cyan
& $python manage.py makemigrations --check --dry-run
$migCheck = $LASTEXITCODE
if ($migCheck -eq 0) {
    Add-Check "migration consistency" $true "No model changes waiting for migrations"
} else {
    Add-Check "migration consistency" $false "Django reports model changes; review before deployment"
}

# Verify the endpoint from Django test client without requiring a browser.
Write-Host ""
Write-Host "---- ENDPOINT TEST ----" -ForegroundColor Cyan
$endpointTest = @'
from django.test import Client
c = Client()
r = c.get("/camera/latest-recognition/")
print("STATUS_CODE:", r.status_code)
print("CONTENT:", r.content.decode("utf-8", errors="replace")[:1000])
'@

& $python manage.py shell -c $endpointTest
$endpointExit = $LASTEXITCODE
Add-Check "latest recognition endpoint test" ($endpointExit -eq 0) "Django test-client execution completed"

# Database summary.
Write-Host ""
Write-Host "---- DATABASE SUMMARY ----" -ForegroundColor Cyan
$dbTest = @'
from face_recognition_app.models import RecognitionLog
print("RecognitionLog count:", RecognitionLog.objects.count())
print("Latest recognition:", RecognitionLog.objects.order_by("-id").values("id","recognized_at","customer_id").first())
'@

& $python manage.py shell -c $dbTest

$reportPath = Join-Path $root "PROJECT_STATUS.txt"
$report += ""
$report += "Backup: $backup"
$report += ""
$report += "Next work should be based on the WARN items above."
$report += "The current POS recognition flow is:"
$report += "Camera -> RecognitionLog -> /camera/latest-recognition/ -> POS polling -> customer auto-select -> Welcome Back popup."
$report | Set-Content -Path $reportPath -Encoding UTF8

Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host " DONE" -ForegroundColor Green
Write-Host " Status report: $reportPath" -ForegroundColor Green
Write-Host " Backup:        $backup" -ForegroundColor Yellow
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Do NOT delete the backup until the project is confirmed working."
