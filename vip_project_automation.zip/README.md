# VIP Recognition Project — Automation Package

## What this does

Run `setup_vip_project.ps1` from PowerShell.

It automatically:

1. Finds the Django project by locating `manage.py`.
2. Finds the existing virtual-environment Python when possible.
3. Creates a timestamped backup of important project files.
4. Locates the recognition `views.py`, POS HTML and app `urls.py`.
5. Checks that `latest_recognition()` exists.
6. Checks that the POS page contains the Welcome Back popup and polling code.
7. Checks that the recognition snapshot element exists.
8. Runs `python manage.py check`.
9. Checks whether model migrations are pending.
10. Tests `/camera/latest-recognition/` through Django's test client.
11. Prints a RecognitionLog database summary.
12. Creates `PROJECT_STATUS.txt` inside the Django project.

## Run

Open PowerShell and use:

```powershell
cd "D:\Downloads\vip-recognition-core"
powershell -ExecutionPolicy Bypass -File ".\setup_vip_project.ps1"
```

If the project is somewhere else, put the script inside the project folder and run it there.

## Important

This package is deliberately conservative. It **does not overwrite your Django source code**.

Before running checks, it creates a backup folder such as:

`_auto_backup_20260805_170000`

That lets you safely continue working with Kiwi/Claude/ChatGPT without losing the current version.

## Current known working flow

Camera recognition creates a `RecognitionLog`.

The POS page polls:

`/camera/latest-recognition/`

When a fresh recognition is returned:

- the customer is auto-selected;
- the Welcome Back popup opens;
- customer name is displayed;
- purchase total is displayed;
- recognition confidence is displayed;
- the recognition snapshot can be displayed when the API returns its `photo` path;
- the popup closes after a few seconds.

The script's purpose is to tell you which parts are currently present and which parts still need work.
